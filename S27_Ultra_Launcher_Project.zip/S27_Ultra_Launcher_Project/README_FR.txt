S27 ULTRA LAUNCHER — Projet Android (Kotlin + Jetpack Compose)  v1.1

NOUVEAUTÉS DE CETTE VERSION
- 4 fonds d'écran (Aurore, Crépuscule, Forêt, Galaxie) avec effet de parallaxe
  (res/drawable-nodpi/wallpaper_1.jpg à wallpaper_4.jpg : tu peux les remplacer
   par de vraies images, garde juste les mêmes noms)
- VRAIS widgets des applications installées (bouton "Ajouter un widget"),
  empilables : balayage vertical pour passer d'un widget à l'autre
- Glisser-déposer des icônes (appui long) avec vibration et animation
- Écran Paramètres : mode sombre/clair, taille de police, courbure et taille des icônes,
  masquer les noms, grille (4x5 à 6x6), fonds d'écran, photo de profil
- Dossier sécurisé protégé par empreinte digitale
- Appareil photo CameraX (avant/arrière, zoom 0.6x à 100x)
- Galerie (grille 3 à 5 colonnes, pincer pour zoomer, visionneuse)

COMMENT COMPILER L'APK
1. Envoie le ZIP sur ton site de compilation (ou ouvre-le dans Android Studio).
2. Commande :  gradle assembleRelease   (Gradle 8.7 ou plus récent, JDK 17)
3. L'APK est dans : app/build/outputs/apk/

COMMENT L'UTILISER
Installe l'APK, appuie sur Accueil, choisis "S27 Ultra Launcher" -> "Toujours".
- Glisser vers le haut : tiroir d'applications
- Glisser vers le bas : panneau de notifications
- Appui long sur une icône : la déplacer
