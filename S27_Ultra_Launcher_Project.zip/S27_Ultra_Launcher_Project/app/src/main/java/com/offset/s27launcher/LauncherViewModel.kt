package com.offset.s27launcher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offset.s27launcher.data.AppIconModel
import com.offset.s27launcher.data.AppRepository
import com.offset.s27launcher.data.DataManager
import com.offset.s27launcher.data.LauncherSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val dm = DataManager(app)
    private val repository = AppRepository(app)

    val settings: StateFlow<LauncherSettings> = dm.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, LauncherSettings())

    val apps: StateFlow<List<AppIconModel>> = repository.observeApps()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    /** Applications visibles (hors dossier sécurisé). */
    private val visibleApps: StateFlow<List<AppIconModel>> = combine(apps, settings) { list, s ->
        list.filter { it.packageName !in s.hiddenApps }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Applications de l'écran d'accueil, dans l'ordre choisi par glisser-déposer. */
    val homeApps: StateFlow<List<AppIconModel>> = combine(visibleApps, settings) { list, s ->
        val index = s.homeOrder.withIndex().associate { it.value to it.index }
        list.sortedWith(compareBy({ index[it.packageName] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
            .take(s.gridColumns * s.gridRows)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val filteredApps: StateFlow<List<AppIconModel>> = combine(visibleApps, _query) { list, q ->
        if (q.isBlank()) list else list.filter { it.label.contains(q, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val hiddenApps: StateFlow<List<AppIconModel>> = combine(apps, settings) { list, s ->
        list.filter { it.packageName in s.hiddenApps }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun setQuery(q: String) { _query.value = q }
    fun setGrid(c: Int, r: Int) { viewModelScope.launch { dm.setGrid(c, r) } }
    fun setIconSize(dp: Int) { viewModelScope.launch { dm.setIconSize(dp) } }
    fun setWallpaper(i: Int) { viewModelScope.launch { dm.setWallpaperIndex(i) } }
    fun setDarkMode(v: Boolean) { viewModelScope.launch { dm.setDarkMode(v) } }
    fun setFontScale(v: Float) { viewModelScope.launch { dm.setFontScale(v) } }
    fun setIconCorner(p: Int) { viewModelScope.launch { dm.setIconCorner(p) } }
    fun setHideLabels(v: Boolean) { viewModelScope.launch { dm.setHideLabels(v) } }
    fun setParallax(v: Boolean) { viewModelScope.launch { dm.setParallax(v) } }
    fun setProfilePhoto(path: String) { viewModelScope.launch { dm.setProfilePhotoPath(path) } }
    fun reorder(newOrder: List<String>) { viewModelScope.launch { dm.setHomeOrder(newOrder) } }

    fun addWidget(id: Int) {
        viewModelScope.launch { dm.setWidgetIds(settings.value.widgetIds + id) }
    }
    fun removeWidget(id: Int) {
        viewModelScope.launch { dm.setWidgetIds(settings.value.widgetIds - id) }
    }
    fun toggleHidden(pkg: String) {
        viewModelScope.launch {
            val cur = settings.value.hiddenApps
            dm.setHiddenApps(if (pkg in cur) cur - pkg else cur + pkg)
        }
    }
}
