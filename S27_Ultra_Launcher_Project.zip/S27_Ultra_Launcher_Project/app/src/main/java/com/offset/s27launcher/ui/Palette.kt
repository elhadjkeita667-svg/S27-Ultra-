package com.offset.s27launcher.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val SamsungBlue = Color(0xFF3E91FF)

class Palette(val bg: Color, val card: Color, val fg: Color, val sub: Color)

/** Couleurs mode sombre / clair avec transition interpolée. */
@Composable
fun rememberPalette(dark: Boolean): Palette {
    val bg by animateColorAsState(if (dark) Color(0xF2111118) else Color(0xF2F3F4F8), tween(450), label = "bg")
    val card by animateColorAsState(if (dark) Color(0x33FFFFFF) else Color(0x14000000), tween(450), label = "card")
    val fg by animateColorAsState(if (dark) Color.White else Color(0xFF111118), tween(450), label = "fg")
    val sub by animateColorAsState(if (dark) Color(0xB3FFFFFF) else Color(0x99000000), tween(450), label = "sub")
    return Palette(bg, card, fg, sub)
}

/** Empêche les touchers de "traverser" un écran superposé. */
@Composable
fun Modifier.consumeTouches(): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})

/** Charge la photo de profil sur un thread d'arrière-plan. */
@Composable
fun rememberProfileBitmap(path: String): State<ImageBitmap?> =
    produceState<ImageBitmap?>(initialValue = null, path) {
        value = if (path.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
            }.getOrNull()
        }
    }
