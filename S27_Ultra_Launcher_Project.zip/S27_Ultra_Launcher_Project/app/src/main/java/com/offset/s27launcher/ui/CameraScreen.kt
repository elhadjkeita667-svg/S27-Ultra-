package com.offset.s27launcher.ui

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.offset.s27launcher.util.Haptics

/** Appareil photo CameraX : avant/arrière, zoom 0.6x à 100x, déclencheur haptique. */
@Composable
fun CameraScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }
    LaunchedEffect(Unit) {
        if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    var useFront by remember { mutableStateOf(false) }
    var zoomLabel by remember { mutableStateOf("1x") }
    var camera by remember { mutableStateOf<Camera?>(null) }
    val previewView = remember { PreviewView(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    DisposableEffect(hasPermission, useFront) {
        val future = ProcessCameraProvider.getInstance(context)
        if (hasPermission) {
            future.addListener({
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    provider.unbindAll()
                    camera = provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
                } catch (e: Exception) {
                    Toast.makeText(context, "Caméra indisponible", Toast.LENGTH_SHORT).show()
                }
            }, ContextCompat.getMainExecutor(context))
        }
        onDispose {
            if (future.isDone) runCatching { future.get().unbindAll() }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).consumeTouches()) {
        if (hasPermission) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                "Autorise l'accès à la caméra pour utiliser l'appareil photo.",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center).padding(32.dp)
            )
        }

        Text(
            "✕",
            color = Color.White,
            fontSize = 24.sp,
            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().clickable(onClick = onClose).padding(16.dp)
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Boutons de zoom Space Zoom
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("0.6x" to 0.6f, "1x" to 1f, "3x" to 3f, "5x" to 5f, "100x" to 100f).forEach { (label, ratio) ->
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(if (zoomLabel == label) Color.White else Color.Black.copy(alpha = 0.5f))
                                .clickable {
                                    zoomLabel = label
                                    val zs = camera?.cameraInfo?.zoomState?.value
                                    val r = ratio.coerceIn(zs?.minZoomRatio ?: 1f, zs?.maxZoomRatio ?: 1f)
                                    camera?.cameraControl?.setZoomRatio(r)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(label, color = if (zoomLabel == label) Color.Black else Color.White, fontSize = 13.sp)
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 24.dp, start = 32.dp, end = 32.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp))
                    // Déclencheur
                    Box(
                        Modifier
                            .size(76.dp)
                            .border(4.dp, Color.White, CircleShape)
                            .padding(8.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable {
                                Haptics.click(context)
                                takePhoto(context, imageCapture)
                            }
                    )
                    // Bascule caméra avant / arrière
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .clickable { useFront = !useFront; zoomLabel = "1x" },
                        contentAlignment = Alignment.Center
                    ) { Text("🔄", fontSize = 22.sp) }
                }
            }
        }
    }
}

private fun takePhoto(context: Context, imageCapture: ImageCapture) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "S27_${System.currentTimeMillis()}")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/S27Launcher")
    }
    val options = ImageCapture.OutputFileOptions.Builder(
        context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
    ).build()
    imageCapture.takePicture(
        options,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                Toast.makeText(context, "Photo enregistrée dans la galerie", Toast.LENGTH_SHORT).show()
            }
            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(context, "Erreur : photo non enregistrée", Toast.LENGTH_SHORT).show()
            }
        }
    )
}
