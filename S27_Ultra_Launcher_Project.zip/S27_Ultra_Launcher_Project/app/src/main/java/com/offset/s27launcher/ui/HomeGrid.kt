package com.offset.s27launcher.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.offset.s27launcher.data.AppIconModel
import com.offset.s27launcher.util.Haptics

@Composable
fun AppIconView(
    app: AppIconModel,
    iconSizeDp: Int,
    cornerPct: Int,
    hideLabel: Boolean,
    labelColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(iconSizeDp.dp)
                .clip(RoundedCornerShape(percent = cornerPct))
        )
        if (!hideLabel) {
            Spacer(Modifier.height(4.dp))
            Text(app.label, color = labelColor, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Grille de l'écran d'accueil avec glisser-déposer :
 * appui long sur une icône, puis déplacement. Vibration fine à la prise
 * et à chaque nouvelle case survolée ; l'icône survolée s'écarte en douceur.
 */
@Composable
fun HomeGrid(
    apps: List<AppIconModel>,
    cols: Int,
    iconSizeDp: Int,
    cornerPct: Int,
    hideLabels: Boolean,
    onLaunch: (String) -> Unit,
    onReorder: (List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bounds = remember { mutableStateMapOf<Int, Rect>() }
    var dragging by remember { mutableIntStateOf(-1) }
    var hover by remember { mutableIntStateOf(-1) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val currentApps by rememberUpdatedState(apps)
    val currentReorder by rememberUpdatedState(onReorder)
    val rows = (apps.size + cols - 1) / cols

    Column(modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        for (r in 0 until rows) {
            val rowActive = dragging in (r * cols) until ((r + 1) * cols)
            Row(Modifier.fillMaxWidth().zIndex(if (rowActive) 1f else 0f)) {
                for (c in 0 until cols) {
                    val idx = r * cols + c
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .zIndex(if (dragging == idx) 1f else 0f)
                            .onGloballyPositioned { bounds[idx] = it.boundsInRoot() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (idx < apps.size) {
                            val app = apps[idx]
                            val target = if (dragging >= 0 && hover == idx && dragging != idx) {
                                val from = bounds[dragging]
                                val to = bounds[idx]
                                if (from != null && to != null) {
                                    Offset(from.left - to.left, from.top - to.top)
                                } else Offset.Zero
                            } else Offset.Zero
                            val shift by animateOffsetAsState(
                                targetValue = target,
                                animationSpec = spring<Offset>(Spring.DampingRatioLowBouncy, Spring.StiffnessLow),
                                label = "shift"
                            )
                            Box(
                                Modifier
                                    .graphicsLayer {
                                        if (dragging == idx) {
                                            translationX = dragOffset.x
                                            translationY = dragOffset.y
                                            scaleX = 1.12f
                                            scaleY = 1.12f
                                        } else {
                                            translationX = shift.x
                                            translationY = shift.y
                                        }
                                    }
                                    .clickable { onLaunch(app.packageName) }
                                    .pointerInput(idx, app.packageName) {
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = {
                                                dragging = idx
                                                hover = -1
                                                dragOffset = Offset.Zero
                                                Haptics.click(context)
                                            },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                dragOffset += amount
                                                val origin = bounds[idx]
                                                if (origin != null) {
                                                    val center = origin.center + dragOffset
                                                    val h = bounds.entries
                                                        .firstOrNull { it.key < currentApps.size && it.value.contains(center) }
                                                        ?.key ?: -1
                                                    if (h != hover) {
                                                        hover = h
                                                        if (h >= 0 && h != idx) Haptics.click(context)
                                                    }
                                                }
                                            },
                                            onDragEnd = {
                                                val from = dragging
                                                val to = hover
                                                if (from >= 0 && to >= 0 && from != to) {
                                                    val list = currentApps.map { it.packageName }.toMutableList()
                                                    java.util.Collections.swap(list, from, to)
                                                    currentReorder(list)
                                                }
                                                dragging = -1
                                                hover = -1
                                                dragOffset = Offset.Zero
                                            },
                                            onDragCancel = {
                                                dragging = -1
                                                hover = -1
                                                dragOffset = Offset.Zero
                                            }
                                        )
                                    }
                            ) {
                                AppIconView(app, iconSizeDp, cornerPct, hideLabels, Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
