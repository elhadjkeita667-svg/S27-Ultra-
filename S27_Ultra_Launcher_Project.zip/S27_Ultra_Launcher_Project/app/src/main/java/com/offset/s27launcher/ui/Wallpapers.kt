package com.offset.s27launcher.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.offset.s27launcher.R

object Wallpapers {
    val ids = listOf(
        R.drawable.wallpaper_1,
        R.drawable.wallpaper_2,
        R.drawable.wallpaper_3,
        R.drawable.wallpaper_4
    )
    val names = listOf("Aurore", "Crépuscule", "Forêt", "Galaxie")
}

/** Fond d'écran avec effet de parallaxe au gyroscope / accéléromètre. */
@Composable
fun WallpaperLayer(index: Int, parallax: Boolean) {
    val context = LocalContext.current
    var tiltX by remember { mutableFloatStateOf(0f) }
    var tiltY by remember { mutableFloatStateOf(0f) }

    DisposableEffect(parallax) {
        if (!parallax) {
            tiltX = 0f
            tiltY = 0f
            return@DisposableEffect onDispose { }
        }
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                tiltX = (-e.values[0] / 5f).coerceIn(-1f, 1f)
                tiltY = ((e.values[1] - 7f) / 5f).coerceIn(-1f, 1f)
            }
            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }

    val ax by animateFloatAsState(tiltX, spring(stiffness = Spring.StiffnessLow), label = "ax")
    val ay by animateFloatAsState(tiltY, spring(stiffness = Spring.StiffnessLow), label = "ay")

    Image(
        painter = painterResource(Wallpapers.ids[index.coerceIn(0, Wallpapers.ids.lastIndex)]),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = 1.12f
                scaleY = 1.12f
                translationX = ax * 45f
                translationY = ay * 45f
            }
    )
}
