package com.offset.s27launcher.ui

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Galerie One UI : grille 3 à 5 colonnes, pincer pour zoomer, visionneuse plein écran. */
@Composable
fun GalleryScreen(palette: Palette, onClose: () -> Unit) {
    val context = LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(permission) }

    val images by produceState<List<Uri>>(emptyList(), granted) {
        value = if (granted) withContext(Dispatchers.IO) { queryImages(context) } else emptyList()
    }

    var columns by remember { mutableIntStateOf(3) }
    var opened by remember { mutableStateOf<Uri?>(null) }

    Box(Modifier.fillMaxSize().background(palette.bg).consumeTouches()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Galerie", color = palette.fg, fontSize = 26.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text("✕", color = palette.fg, fontSize = 22.sp, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
            }
            if (!granted) {
                Text("Autorise l'accès aux photos pour afficher la galerie.", color = palette.sub, modifier = Modifier.padding(16.dp))
            } else if (images.isEmpty()) {
                Text("Aucune photo trouvée.", color = palette.sub, modifier = Modifier.padding(16.dp))
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier
                    .weight(1f)
                    .pointerInput(Unit) {
                        // Pincer à deux doigts : 3 colonnes <-> 5 colonnes
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            var acc = 1f
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.size >= 2) {
                                    acc *= event.calculateZoom()
                                    if (acc > 1.3f) { columns = (columns - 1).coerceAtLeast(3); acc = 1f }
                                    else if (acc < 0.75f) { columns = (columns + 1).coerceAtMost(5); acc = 1f }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
            ) {
                items(images, key = { it.toString() }) { uri ->
                    val thumb by produceState<ImageBitmap?>(null, uri) {
                        value = withContext(Dispatchers.IO) { loadThumb(context, uri) }
                    }
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .background(palette.card)
                            .clickable { opened = uri }
                    ) {
                        thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    }
                }
            }
        }

        opened?.let { uri -> Viewer(uri, onClose = { opened = null }) }
    }
}

@Composable
private fun Viewer(uri: Uri, onClose: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { loadFull(context, uri) }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offX by remember { mutableFloatStateOf(0f) }
    var offY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize().background(Color.Black).consumeTouches()) {
        bitmap?.let {
            Image(
                it, null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offX += pan.x
                            offY += pan.y
                        }
                    }
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offX; translationY = offY }
            )
        }
        Text(
            "✕", color = Color.White, fontSize = 24.sp,
            modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().clickable(onClick = onClose).padding(16.dp)
        )
    }
}

private fun queryImages(context: Context): List<Uri> {
    val list = mutableListOf<Uri>()
    val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    context.contentResolver.query(
        collection, arrayOf(MediaStore.Images.Media._ID), null, null,
        "${MediaStore.Images.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        while (c.moveToNext() && list.size < 500) {
            list += ContentUris.withAppendedId(collection, c.getLong(idCol))
        }
    }
    return list
}

private fun loadThumb(context: Context, uri: Uri): ImageBitmap? = runCatching {
    if (Build.VERSION.SDK_INT >= 29) {
        context.contentResolver.loadThumbnail(uri, Size(256, 256), null).asImageBitmap()
    } else {
        val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts)?.asImageBitmap() }
    }
}.getOrNull()

private fun loadFull(context: Context, uri: Uri): ImageBitmap? = runCatching {
    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts)?.asImageBitmap() }
}.getOrNull()
