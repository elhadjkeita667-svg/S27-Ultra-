package com.offset.s27launcher.widgets

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity

data class WidgetProviderModel(
    val label: String,
    val appName: String,
    val info: AppWidgetProviderInfo,
    val preview: ImageBitmap?
)

/** Héberge les VRAIS widgets Android des applications installées. */
class WidgetController(
    private val activity: FragmentActivity,
    private val onAdded: (Int) -> Unit,
    private val onRemoved: (Int) -> Unit
) {
    companion object {
        const val HOST_ID = 2026
        const val REQ_CONFIGURE = 4021
    }

    val host = AppWidgetHost(activity, HOST_ID)
    private val manager: AppWidgetManager = AppWidgetManager.getInstance(activity)
    private var pendingId = -1

    private val bindLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) configureOrFinish(pendingId) else cancelPending()
    }

    fun start() { host.startListening() }
    fun stop() { try { host.stopListening() } catch (_: Exception) { } }

    /** Liste tous les widgets proposés par les applications installées. */
    fun providers(): List<WidgetProviderModel> {
        val pm = activity.packageManager
        return manager.installedProviders.map { info ->
            val appName = runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
            }.getOrDefault("")
            WidgetProviderModel(
                label = info.loadLabel(pm) ?: "Widget",
                appName = appName,
                info = info,
                preview = runCatching {
                    info.loadPreviewImage(activity, 0)?.toBitmap(256, 256)?.asImageBitmap()
                }.getOrNull()
            )
        }.sortedBy { it.appName.lowercase() + it.label.lowercase() }
    }

    fun add(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrFinish(id)
        } else {
            // Android demande à l'utilisateur d'autoriser ce widget
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            bindLauncher.launch(intent)
        }
    }

    private fun configureOrFinish(id: Int) {
        val info = manager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(activity, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                finish(id)
            }
        } else {
            finish(id)
        }
    }

    fun onActivityResult(requestCode: Int, resultCode: Int) {
        if (requestCode == REQ_CONFIGURE) {
            if (resultCode == Activity.RESULT_OK) finish(pendingId) else cancelPending()
        }
    }

    private fun finish(id: Int) {
        pendingId = -1
        onAdded(id)
    }

    private fun cancelPending() {
        if (pendingId != -1) host.deleteAppWidgetId(pendingId)
        pendingId = -1
    }

    fun remove(id: Int) {
        host.deleteAppWidgetId(id)
        onRemoved(id)
    }

    fun createView(id: Int): View? {
        val info = manager.getAppWidgetInfo(id) ?: return null
        return host.createView(activity, id, info)
    }
}
