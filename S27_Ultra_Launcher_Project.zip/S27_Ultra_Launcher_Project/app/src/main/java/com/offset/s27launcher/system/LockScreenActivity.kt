package com.offset.s27launcher.system

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Écran de verrouillage simulé : glisser vers le haut (ou toucher) pour revenir au bureau. */
class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemOverlayManager.enterImmersive(window)
        setContent { LockScreen(onUnlock = { finish() }) }
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val now by produceState(initialValue = Date()) {
        while (true) { value = Date(); delay(10_000) }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B1B3F))
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -150f) onUnlock() }
                ) { _, dy -> total += dy }
            }
            .clickable { onUnlock() }
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
            color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light
        )
        Text(
            SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now),
            color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp
        )
        Text(
            "Glisser vers le haut pour déverrouiller",
            color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
            modifier = Modifier.padding(top = 48.dp)
        )
    }
}
