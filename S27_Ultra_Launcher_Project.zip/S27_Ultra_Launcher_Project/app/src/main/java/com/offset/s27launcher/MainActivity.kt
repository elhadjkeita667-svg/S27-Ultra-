package com.offset.s27launcher

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.offset.s27launcher.ui.LauncherActions
import com.offset.s27launcher.ui.LauncherApp
import com.offset.s27launcher.widgets.WidgetController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : FragmentActivity() {

    private val viewModel: LauncherViewModel by viewModels()
    private lateinit var widgetController: WidgetController

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                val file = File(filesDir, "profile_${System.currentTimeMillis()}.jpg")
                contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { output -> input.copyTo(output) }
                }
                viewModel.setProfilePhoto(file.absolutePath)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        widgetController = WidgetController(
            activity = this,
            onAdded = { viewModel.addWidget(it) },
            onRemoved = { viewModel.removeWidget(it) }
        )

        val actions = LauncherActions(
            launch = { launchApp(it) },
            setBrightness = { setBrightness(it) },
            pickPhoto = { pickPhoto.launch("image/*") },
            authenticate = { authenticate(it) },
            widgets = widgetController
        )
        setContent { LauncherApp(vm = viewModel, actions = actions) }
    }

    override fun onStart() {
        super.onStart()
        widgetController.start()
    }

    override fun onStop() {
        super.onStop()
        widgetController.stop()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        widgetController.onActivityResult(requestCode, resultCode)
    }

    private fun setBrightness(value: Float) {
        val lp = window.attributes
        lp.screenBrightness = value.coerceIn(0.02f, 1f)
        window.attributes = lp
    }

    private fun launchApp(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    /** Dossier sécurisé : empreinte digitale obligatoire. */
    private fun authenticate(onSuccess: () -> Unit) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (BiometricManager.from(this).canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Aucune empreinte digitale configurée sur ce téléphone", Toast.LENGTH_LONG).show()
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Dossier sécurisé")
            .setSubtitle("Posez votre doigt sur le capteur")
            .setAllowedAuthenticators(authenticators)
            .setNegativeButtonText("Annuler")
            .build()
        prompt.authenticate(info)
    }
}
