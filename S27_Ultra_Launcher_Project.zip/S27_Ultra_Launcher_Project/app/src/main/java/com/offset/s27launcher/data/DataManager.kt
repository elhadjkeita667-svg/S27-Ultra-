package com.offset.s27launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "s27_prefs")

data class LauncherSettings(
    val iconSizeDp: Int = 56,
    val gridColumns: Int = 4,
    val gridRows: Int = 5,
    val profilePhotoPath: String = "",
    val wallpaperIndex: Int = 0,
    val darkMode: Boolean = true,
    val fontScale: Float = 1f,
    val iconCornerPct: Int = 30,
    val hideLabels: Boolean = false,
    val parallax: Boolean = true,
    val widgetIds: List<Int> = emptyList(),
    val homeOrder: List<String> = emptyList(),
    val hiddenApps: Set<String> = emptySet()
)

class DataManager(private val context: Context) {

    private object Keys {
        val ICON_SIZE = intPreferencesKey("icon_size")
        val GRID_COLUMNS = intPreferencesKey("grid_columns")
        val GRID_ROWS = intPreferencesKey("grid_rows")
        val PROFILE_PHOTO = stringPreferencesKey("profile_photo_path")
        val WALLPAPER = intPreferencesKey("wallpaper_index")
        val DARK = booleanPreferencesKey("dark_mode")
        val FONT = floatPreferencesKey("font_scale")
        val CORNER = intPreferencesKey("icon_corner_pct")
        val HIDE_LABELS = booleanPreferencesKey("hide_labels")
        val PARALLAX = booleanPreferencesKey("parallax")
        val WIDGETS = stringPreferencesKey("widget_ids")
        val ORDER = stringPreferencesKey("home_order")
        val HIDDEN = stringSetPreferencesKey("hidden_apps")
    }

    val settings: Flow<LauncherSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            LauncherSettings(
                iconSizeDp = p[Keys.ICON_SIZE] ?: 56,
                gridColumns = p[Keys.GRID_COLUMNS] ?: 4,
                gridRows = p[Keys.GRID_ROWS] ?: 5,
                profilePhotoPath = p[Keys.PROFILE_PHOTO] ?: "",
                wallpaperIndex = p[Keys.WALLPAPER] ?: 0,
                darkMode = p[Keys.DARK] ?: true,
                fontScale = p[Keys.FONT] ?: 1f,
                iconCornerPct = p[Keys.CORNER] ?: 30,
                hideLabels = p[Keys.HIDE_LABELS] ?: false,
                parallax = p[Keys.PARALLAX] ?: true,
                widgetIds = (p[Keys.WIDGETS] ?: "").split(",").mapNotNull { it.toIntOrNull() },
                homeOrder = (p[Keys.ORDER] ?: "").split("\n").filter { it.isNotBlank() },
                hiddenApps = p[Keys.HIDDEN] ?: emptySet()
            )
        }

    suspend fun setIconSize(dp: Int) = context.dataStore.edit { it[Keys.ICON_SIZE] = dp.coerceIn(40, 80) }
    suspend fun setGrid(columns: Int, rows: Int) = context.dataStore.edit {
        it[Keys.GRID_COLUMNS] = columns
        it[Keys.GRID_ROWS] = rows
    }
    suspend fun setProfilePhotoPath(path: String) = context.dataStore.edit { it[Keys.PROFILE_PHOTO] = path }
    suspend fun setWallpaperIndex(index: Int) = context.dataStore.edit { it[Keys.WALLPAPER] = index }
    suspend fun setDarkMode(v: Boolean) = context.dataStore.edit { it[Keys.DARK] = v }
    suspend fun setFontScale(v: Float) = context.dataStore.edit { it[Keys.FONT] = v.coerceIn(0.8f, 1.4f) }
    suspend fun setIconCorner(pct: Int) = context.dataStore.edit { it[Keys.CORNER] = pct.coerceIn(0, 50) }
    suspend fun setHideLabels(v: Boolean) = context.dataStore.edit { it[Keys.HIDE_LABELS] = v }
    suspend fun setParallax(v: Boolean) = context.dataStore.edit { it[Keys.PARALLAX] = v }
    suspend fun setWidgetIds(ids: List<Int>) = context.dataStore.edit { it[Keys.WIDGETS] = ids.joinToString(",") }
    suspend fun setHomeOrder(order: List<String>) = context.dataStore.edit { it[Keys.ORDER] = order.joinToString("\n") }
    suspend fun setHiddenApps(set: Set<String>) = context.dataStore.edit { it[Keys.HIDDEN] = set }
}
