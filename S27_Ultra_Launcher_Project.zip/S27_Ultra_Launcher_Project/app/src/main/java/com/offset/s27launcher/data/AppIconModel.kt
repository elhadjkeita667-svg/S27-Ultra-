package com.offset.s27launcher.data

import androidx.compose.ui.graphics.ImageBitmap

/** Modèle d'une application installée affichée dans la grille. */
data class AppIconModel(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap
)
