@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.offset.s27launcher.ui

import android.view.View
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.offset.s27launcher.LauncherViewModel
import com.offset.s27launcher.data.AppIconModel
import com.offset.s27launcher.util.Haptics
import com.offset.s27launcher.widgets.WidgetController
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ponts entre l'interface Compose et l'Activity. */
class LauncherActions(
    val launch: (String) -> Unit,
    val setBrightness: (Float) -> Unit,
    val pickPhoto: () -> Unit,
    val authenticate: (() -> Unit) -> Unit,
    val widgets: WidgetController
)

private enum class Screen { NONE, DRAWER, PANEL, SETTINGS, CAMERA, GALLERY, SECRET, WIDGETS }

@Composable
fun LauncherApp(vm: LauncherViewModel, actions: LauncherActions) {
    val settings by vm.settings.collectAsState()
    val homeApps by vm.homeApps.collectAsState()
    val drawerApps by vm.filteredApps.collectAsState()
    val hiddenApps by vm.hiddenApps.collectAsState()
    val query by vm.query.collectAsState()
    val context = LocalContext.current
    val palette = rememberPalette(settings.darkMode)
    val baseDensity = LocalDensity.current
    val profile by rememberProfileBitmap(settings.profilePhotoPath)
    var screen by remember { mutableStateOf(Screen.NONE) }

    BackHandler(enabled = screen != Screen.NONE) {
        screen = Screen.NONE
        vm.setQuery("")
    }

    // Flou "verre dépoli" (Android 12+, ignoré proprement avant)
    val blurRadius by animateDpAsState(
        targetValue = if (screen != Screen.NONE) 24.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy),
        label = "blur"
    )

    MaterialTheme(colorScheme = if (settings.darkMode) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, settings.fontScale)) {
            Box(Modifier.fillMaxSize()) {

                WallpaperLayer(settings.wallpaperIndex, settings.parallax)

                // ---------- ÉCRAN D'ACCUEIL ----------
                Column(
                    Modifier
                        .fillMaxSize()
                        .blur(blurRadius)
                        .pointerInput(Unit) {
                            var total = 0f
                            detectVerticalDragGestures(
                                onDragStart = { total = 0f },
                                onDragEnd = {
                                    if (total > 140f) screen = Screen.PANEL
                                    else if (total < -140f) screen = Screen.DRAWER
                                }
                            ) { _, dy -> total += dy }
                        }
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp)
                ) {
                    WidgetArea(
                        ids = settings.widgetIds,
                        actions = actions,
                        onAdd = { screen = Screen.WIDGETS }
                    )
                    Spacer(Modifier.height(10.dp))
                    HomeGrid(
                        apps = homeApps,
                        cols = settings.gridColumns,
                        iconSizeDp = settings.iconSizeDp,
                        cornerPct = settings.iconCornerPct,
                        hideLabels = settings.hideLabels,
                        onLaunch = actions.launch,
                        onReorder = { vm.reorder(it) },
                        modifier = Modifier.weight(1f)
                    )
                    Dock(
                        onCamera = { screen = Screen.CAMERA },
                        onGallery = { screen = Screen.GALLERY },
                        onSecret = { actions.authenticate { screen = Screen.SECRET } },
                        onSettings = { screen = Screen.SETTINGS }
                    )
                    SearchPill(onClick = { screen = Screen.DRAWER })
                }

                // ---------- TIROIR D'APPLICATIONS ----------
                SlideOverlay(screen == Screen.DRAWER) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .background(palette.bg)
                            .consumeTouches()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .padding(16.dp)
                    ) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { vm.setQuery(it) },
                            placeholder = { Text("Rechercher une application") },
                            singleLine = true,
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(settings.gridColumns),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(drawerApps, key = { it.packageName }) { app ->
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .combinedClickable(
                                            onClick = {
                                                screen = Screen.NONE
                                                vm.setQuery("")
                                                actions.launch(app.packageName)
                                            },
                                            onLongClick = {
                                                Haptics.click(context)
                                                vm.toggleHidden(app.packageName)
                                                Toast.makeText(context, "${app.label} → dossier sécurisé 🔒", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppIconView(app, settings.iconSizeDp, settings.iconCornerPct, settings.hideLabels, palette.fg)
                                }
                            }
                        }
                        Text(
                            "Appui long sur une app : l'envoyer dans le dossier sécurisé 🔒",
                            color = palette.sub, fontSize = 11.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }

                // ---------- PANNEAU DE NOTIFICATIONS ----------
                SlideOverlay(screen == Screen.PANEL, fromTop = true) {
                    NotificationPanel(
                        palette = palette,
                        profile = profile,
                        onBrightness = actions.setBrightness,
                        onSettings = { screen = Screen.SETTINGS },
                        onClose = { screen = Screen.NONE }
                    )
                }

                // ---------- PARAMÈTRES ----------
                SlideOverlay(screen == Screen.SETTINGS) {
                    SettingsScreen(
                        settings = settings,
                        palette = palette,
                        profile = profile,
                        onPickPhoto = actions.pickPhoto,
                        onDark = { vm.setDarkMode(it) },
                        onFont = { vm.setFontScale(it) },
                        onCorner = { vm.setIconCorner(it) },
                        onIconSize = { vm.setIconSize(it) },
                        onHideLabels = { vm.setHideLabels(it) },
                        onGrid = { c, r -> vm.setGrid(c, r) },
                        onWallpaper = { vm.setWallpaper(it) },
                        onParallax = { vm.setParallax(it) },
                        onAddWidget = { screen = Screen.WIDGETS },
                        onClose = { screen = Screen.NONE }
                    )
                }

                // ---------- WIDGETS ----------
                SlideOverlay(screen == Screen.WIDGETS) {
                    WidgetPicker(
                        controller = actions.widgets,
                        palette = palette,
                        onPick = { info ->
                            actions.widgets.add(info)
                            screen = Screen.NONE
                        },
                        onClose = { screen = Screen.NONE }
                    )
                }

                // ---------- APPAREIL PHOTO ----------
                SlideOverlay(screen == Screen.CAMERA) {
                    CameraScreen(onClose = { screen = Screen.NONE })
                }

                // ---------- GALERIE ----------
                SlideOverlay(screen == Screen.GALLERY) {
                    GalleryScreen(palette = palette, onClose = { screen = Screen.NONE })
                }

                // ---------- DOSSIER SÉCURISÉ ----------
                SlideOverlay(screen == Screen.SECRET) {
                    SecretFolder(
                        apps = hiddenApps,
                        palette = palette,
                        iconSize = settings.iconSizeDp,
                        corner = settings.iconCornerPct,
                        columns = settings.gridColumns,
                        onLaunch = actions.launch,
                        onRestore = {
                            Haptics.click(context)
                            vm.toggleHidden(it)
                        },
                        onClose = { screen = Screen.NONE }
                    )
                }
            }
        }
    }
}

@Composable
private fun SlideOverlay(visible: Boolean, fromTop: Boolean = false, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            animationSpec = spring<IntOffset>(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)
        ) { if (fromTop) -it else it } + fadeIn(),
        exit = slideOutVertically { if (fromTop) -it else it } + fadeOut()
    ) { content() }
}

// ======================= WIDGETS EMPILABLES =======================

@Composable
private fun WidgetArea(ids: List<Int>, actions: LauncherActions, onAdd: () -> Unit) {
    if (ids.isEmpty()) {
        ClockWidget()
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black.copy(alpha = 0.3f))
                .clickable(onClick = onAdd)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) { Text("➕  Ajouter un widget", color = Color.White, fontSize = 13.sp) }
        return
    }

    val pagerState = rememberPagerState(pageCount = { ids.size })
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 16.dp)
            .height(180.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.Black.copy(alpha = 0.25f))
    ) {
        // Balayage vertical pour passer d'un widget à l'autre au même emplacement
        VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val id = ids[page]
            key(id) {
                AndroidView(
                    factory = { ctx -> actions.widgets.createView(id) ?: View(ctx) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Row(Modifier.align(Alignment.TopEnd)) {
            Text("＋", color = Color.White, fontSize = 20.sp,
                modifier = Modifier.clickable(onClick = onAdd).padding(8.dp))
            Text("✕", color = Color.White, fontSize = 18.sp,
                modifier = Modifier.clickable {
                    val current = pagerState.currentPage.coerceIn(0, ids.lastIndex)
                    actions.widgets.remove(ids[current])
                }.padding(8.dp))
        }
        if (ids.size > 1) {
            Column(Modifier.align(Alignment.CenterEnd).padding(end = 6.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                ids.indices.forEach { i ->
                    Box(
                        Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (i == pagerState.currentPage) Color.White else Color.White.copy(alpha = 0.4f))
                    )
                }
            }
        }
    }
}

@Composable
private fun ClockWidget() {
    val now by produceState(initialValue = Date()) {
        while (true) {
            value = Date()
            delay(15_000)
        }
    }
    val hour = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .padding(20.dp)
    ) {
        Text(hour, color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
        Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
        Spacer(Modifier.height(6.dp))
        Text("☁️  22°C  Partiellement nuageux", color = Color.White, fontSize = 14.sp)
    }
}

// ======================= DOCK & RECHERCHE =======================

@Composable
private fun Dock(onCamera: () -> Unit, onGallery: () -> Unit, onSecret: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        DockItem("📷", "Photo", onCamera)
        DockItem("🖼️", "Galerie", onGallery)
        DockItem("🔒", "Sécurisé", onSecret)
        DockItem("⚙️", "Réglages", onSettings)
    }
}

@Composable
private fun DockItem(emoji: String, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(emoji, fontSize = 26.sp)
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.2f))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text("🔍  Rechercher", color = Color.White, fontSize = 15.sp)
    }
}

// ======================= DOSSIER SÉCURISÉ =======================

@Composable
private fun SecretFolder(
    apps: List<AppIconModel>,
    palette: Palette,
    iconSize: Int,
    corner: Int,
    columns: Int,
    onLaunch: (String) -> Unit,
    onRestore: (String) -> Unit,
    onClose: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(palette.bg)
            .consumeTouches()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🔒 Dossier sécurisé", color = palette.fg, fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("✕", color = palette.fg, fontSize = 22.sp, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
        }
        Spacer(Modifier.height(12.dp))
        if (apps.isEmpty()) {
            Text("Vide. Dans le tiroir d'applications, fais un appui long sur une app pour l'ajouter ici.", color = palette.sub)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(apps, key = { it.packageName }) { app ->
                Box(
                    Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .combinedClickable(
                            onClick = { onLaunch(app.packageName) },
                            onLongClick = { onRestore(app.packageName) }
                        )
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) { AppIconView(app, iconSize, corner, false, palette.fg) }
            }
        }
        Text(
            "Appui long : sortir l'app du dossier",
            color = palette.sub, fontSize = 11.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
    }
}

// ======================= PANNEAU DE NOTIFICATIONS =======================

@Composable
private fun NotificationPanel(
    palette: Palette,
    profile: ImageBitmap?,
    onBrightness: (Float) -> Unit,
    onSettings: () -> Unit,
    onClose: () -> Unit
) {
    var brightness by remember { mutableFloatStateOf(0.6f) }
    val tiles = remember {
        mutableStateListOf(
            "Wi-Fi" to true, "Bluetooth" to true, "Son" to true, "Rotation" to false,
            "Avion" to false, "Lampe" to false, "NFC" to true, "Partage" to false
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(palette.bg)
            .consumeTouches()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(SamsungBlue), contentAlignment = Alignment.Center) {
                if (profile != null) {
                    Image(profile, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else Text("👤", fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text("Galaxy S27 Ultra", color = palette.fg, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("⚙️", fontSize = 22.sp, modifier = Modifier.clickable(onClick = onSettings).padding(8.dp))
            Text("✕", color = palette.fg, fontSize = 22.sp, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
        }
        Spacer(Modifier.height(16.dp))

        for (rowIndex in 0 until 2) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (col in 0 until 4) {
                    val idx = rowIndex * 4 + col
                    val (name, on) = tiles[idx]
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (on) SamsungBlue else palette.card)
                            .clickable { tiles[idx] = name to !on }
                            .padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(name, color = if (on) Color.White else palette.fg, fontSize = 11.sp, maxLines = 1) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Text("Luminosité", color = palette.fg, fontSize = 13.sp)
        Slider(
            value = brightness,
            onValueChange = { brightness = it; onBrightness(it) },
            valueRange = 0.02f..1f
        )

        Spacer(Modifier.height(12.dp))
        Text("Notifications", color = palette.fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        listOf(
            "Messages" to "Nouveau message de Mamadou",
            "Samsung Health" to "Objectif d'hydratation : 5/8 verres",
            "Système" to "Optimisation Galaxy terminée"
        ).forEach { (title, body) ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(palette.card)
                    .padding(14.dp)
            ) {
                Text(title, color = palette.sub, fontSize = 11.sp)
                Text(body, color = palette.fg, fontSize = 14.sp)
            }
        }
    }
}
