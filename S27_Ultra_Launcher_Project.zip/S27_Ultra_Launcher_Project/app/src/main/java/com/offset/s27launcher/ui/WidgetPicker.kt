package com.offset.s27launcher.ui

import android.appwidget.AppWidgetProviderInfo
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.offset.s27launcher.widgets.WidgetController
import com.offset.s27launcher.widgets.WidgetProviderModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Liste de tous les widgets des applications installées. */
@Composable
fun WidgetPicker(
    controller: WidgetController,
    palette: Palette,
    onPick: (AppWidgetProviderInfo) -> Unit,
    onClose: () -> Unit
) {
    val items by produceState<List<WidgetProviderModel>>(emptyList()) {
        value = withContext(Dispatchers.IO) { controller.providers() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(palette.bg)
            .consumeTouches()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Widgets", color = palette.fg, fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("✕", color = palette.fg, fontSize = 22.sp, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
        }
        Spacer(Modifier.height(8.dp))
        if (items.isEmpty()) {
            Text("Chargement des widgets…", color = palette.sub)
        }
        LazyColumn(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            items(items) { m ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(palette.card)
                        .clickable { onPick(m.info) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (m.preview != null) {
                        Image(m.preview, null, Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                    } else {
                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(palette.card), contentAlignment = Alignment.Center) {
                            Text("🧩", fontSize = 26.sp)
                        }
                    }
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(m.label, color = palette.fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(m.appName, color = palette.sub, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
