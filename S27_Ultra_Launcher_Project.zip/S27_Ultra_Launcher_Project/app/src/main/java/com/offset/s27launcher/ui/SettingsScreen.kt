package com.offset.s27launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.offset.s27launcher.data.LauncherSettings

@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    palette: Palette,
    profile: ImageBitmap?,
    onPickPhoto: () -> Unit,
    onDark: (Boolean) -> Unit,
    onFont: (Float) -> Unit,
    onCorner: (Int) -> Unit,
    onIconSize: (Int) -> Unit,
    onHideLabels: (Boolean) -> Unit,
    onGrid: (Int, Int) -> Unit,
    onWallpaper: (Int) -> Unit,
    onParallax: (Boolean) -> Unit,
    onAddWidget: () -> Unit,
    onClose: () -> Unit
) {
    var font by remember(settings.fontScale) { mutableFloatStateOf(settings.fontScale) }
    var corner by remember(settings.iconCornerPct) { mutableFloatStateOf(settings.iconCornerPct.toFloat()) }
    var size by remember(settings.iconSizeDp) { mutableFloatStateOf(settings.iconSizeDp.toFloat()) }
    val grids = listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6, 6 to 6)

    Column(
        Modifier
            .fillMaxSize()
            .background(palette.bg)
            .consumeTouches()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Paramètres", color = palette.fg, fontSize = 26.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("✕", color = palette.fg, fontSize = 22.sp, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
        }

        Section("Profil", palette)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(SamsungBlue), contentAlignment = Alignment.Center) {
                if (profile != null) {
                    Image(profile, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else Text("👤", fontSize = 28.sp)
            }
            Spacer(Modifier.width(16.dp))
            Pill("Choisir une photo", palette, onPickPhoto)
        }

        Section("Affichage", palette)
        SwitchRow("Mode sombre", settings.darkMode, palette, onDark)
        Label("Taille de la police : ${(font * 100).toInt()} %", palette)
        Slider(font, { font = it }, valueRange = 0.8f..1.4f, onValueChangeFinished = { onFont(font) })
        Label("Rayon de courbure des icônes : ${corner.toInt()} %", palette)
        Slider(corner, { corner = it }, valueRange = 0f..50f, onValueChangeFinished = { onCorner(corner.toInt()) })
        Label("Taille des icônes : ${size.toInt()} dp", palette)
        Slider(size, { size = it }, valueRange = 40f..80f, onValueChangeFinished = { onIconSize(size.toInt()) })
        SwitchRow("Masquer le nom des applications", settings.hideLabels, palette, onHideLabels)

        Section("Écran d'accueil", palette)
        Label("Grille", palette)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            grids.forEach { (c, r) ->
                FilterChip(
                    selected = c == settings.gridColumns && r == settings.gridRows,
                    onClick = { onGrid(c, r) },
                    label = { Text("${c}x$r") }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Pill("➕ Ajouter un widget", palette, onAddWidget)

        Section("Fonds d'écran", palette)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Wallpapers.ids.forEachIndexed { i, id ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val shape = RoundedCornerShape(16.dp)
                    Image(
                        painter = painterResource(id),
                        contentDescription = Wallpapers.names[i],
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp, 128.dp)
                            .clip(shape)
                            .then(if (i == settings.wallpaperIndex) Modifier.border(3.dp, SamsungBlue, shape) else Modifier)
                            .clickable { onWallpaper(i) }
                    )
                    Text(Wallpapers.names[i], color = palette.sub, fontSize = 11.sp)
                }
            }
        }
        SwitchRow("Effet de parallaxe (gyroscope)", settings.parallax, palette, onParallax)

        Section("Dossier sécurisé", palette)
        Text(
            "Dans le tiroir d'applications, fais un appui long sur une application pour l'envoyer dans le dossier sécurisé (🔒). Il s'ouvre avec l'empreinte digitale.",
            color = palette.sub, fontSize = 13.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, palette: Palette) {
    Spacer(Modifier.height(20.dp))
    Text(title, color = SamsungBlue, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun Label(text: String, palette: Palette) {
    Text(text, color = palette.fg, fontSize = 14.sp)
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, palette: Palette, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = palette.fg, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Pill(text: String, palette: Palette, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(palette.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) { Text(text, color = palette.fg, fontSize = 14.sp) }
}
